function Sezer(matn = ''){

    let alif = ['a','b','c','d','e','f','g','h','i',
    'j','k' ,'l', 'm', 'n', 'o', 'p' ,'q','r',
    's','t','u', 'v' ,'w','x', 'y','z'
    ]
    matn = matn.toLowerCase()
    s = ''
    for(let i = 0 ; i<matn.length; i++){
        for(let j = 0 ; j<alif.length; j++){
            if(matn[i] == alif[j]){
                s+=alif[(j+5) % 26]
                break
            }
            else{
                s+=matn[i]
                break
            }
        }
    }
    
    return s
    }
    console.log(Sezer('az1!234'))