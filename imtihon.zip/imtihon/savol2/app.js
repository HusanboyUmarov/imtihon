function EKUB(a , b){
    for(let i = Math.min(a, b) ;i>=2  ; i--){
        if(a % i == 0 && b % i == 0){
            return i
        }
    }
return 1
}
console.log(EKUB(2, 1))