const btn = document.querySelector('button')
const body = document.querySelector('body')

function randomColor(){
    arr = ['0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f']
    s= ''
    for(let i = 0 ; i<6; i++){
        s+=arr[Math.floor(Math.random() * 16)]
    }
    return s
}
console.log(randomColor())
btn.addEventListener('click' , el=>{
    body.style.backgroundColor = `#${randomColor()}`
})